const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

let x = Math.random() * 350;
let y = Math.random() * 350;
let score = 0;

function drawBall() {
  ctx.clearRect(0, 0, 400, 400);
  ctx.beginPath();
  ctx.arc(x, y, 20, 0, Math.PI * 2);
  ctx.fillStyle = "#ff4757";
  ctx.fill();
  ctx.closePath();
}

canvas.addEventListener('click', (e) => {
  const rect = canvas.getBoundingClientRect();
  const clickX = e.clientX - rect.left;
  const clickY = e.clientY - rect.top;
  const dist = Math.sqrt((clickX - x) ** 2 + (clickY - y) ** 2);
  if (dist < 20) {
    score++;
    x = Math.random() * 350;
    y = Math.random() * 350;
    alert("Hit! Score: " + score);
  }
});

drawBall();